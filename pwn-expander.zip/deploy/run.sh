#!/bin/bash

su ctf -c "timeout 60 /home/ctf/prob"